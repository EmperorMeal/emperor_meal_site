
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";
import { Facebook, Twitter, Instagram } from "lucide-react";

export default function EmperorsMeal() {
  return (
    <div className="bg-blue-100 text-gray-800 min-h-screen">
      <header className="bg-blue-600 text-white p-6 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-3xl font-bold">Emperors Meal</h1>
          <nav className="space-x-4">
            <a href="#about" className="hover:underline">Who We Are</a>
            <a href="#services" className="hover:underline">Services</a>
            <a href="#stories" className="hover:underline">Success Stories</a>
            <a href="#volunteer" className="hover:underline">Volunteer</a>
            <a href="#donate" className="hover:underline">Donate</a>
            <a href="#contact" className="hover:underline">Contact</a>
          </nav>
        </div>
      </header>
      <section className="text-center py-20 bg-blue-200">
        <motion.h2 className="text-4xl font-bold mb-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
          Every Child Deserves a Healthy Meal
        </motion.h2>
        <p className="mb-6">Join us in our mission to feed the future, one child at a time.</p>
        <div className="space-x-4">
          <Button>Donate Now</Button>
          <Button variant="outline">Become a Volunteer</Button>
        </div>
      </section>
      <section id="about" className="py-12 px-4 max-w-4xl mx-auto">
        <h3 className="text-2xl font-bold mb-4">Who We Are</h3>
        <p>
          Emperors Meal is a humanitarian NGO committed to ensuring that every child receives a healthy meal per day. We work with internally displaced persons (IDPs) and less privileged children across Nigeria.
        </p>
      </section>
      <section id="services" className="py-12 px-4 bg-blue-50">
        <h3 className="text-2xl font-bold mb-6 text-center">Our Services</h3>
        <div className="grid md:grid-cols-3 gap-6">
          <Card><CardContent className="p-4">Meal Distribution</CardContent></Card>
          <Card><CardContent className="p-4">School Feeding Support</CardContent></Card>
          <Card><CardContent className="p-4">Nutrition Awareness</CardContent></Card>
        </div>
      </section>
      <section id="stories" className="py-12 px-4 max-w-4xl mx-auto">
        <h3 className="text-2xl font-bold mb-4">Success Stories</h3>
        <p>See how we've made an impact in the lives of children and families through food and care.</p>
      </section>
      <section id="volunteer" className="py-12 px-4 bg-blue-50">
        <h3 className="text-2xl font-bold mb-4">Volunteer With Us</h3>
        <form className="space-y-4 max-w-xl mx-auto">
          <Input placeholder="Full Name" />
          <Input placeholder="Email Address" />
          <Input placeholder="Phone Number" />
          <Textarea placeholder="Why do you want to volunteer?" />
          <Button>Submit</Button>
        </form>
      </section>
      <section id="donate" className="py-12 px-4">
        <h3 className="text-2xl font-bold mb-4">Make a Donation</h3>
        <form className="space-y-4 max-w-xl mx-auto">
          <Input placeholder="Full Name" />
          <Input placeholder="Email Address" />
          <Input placeholder="Donation Amount (₦)" type="number" />
          <select className="w-full p-2 rounded border">
            <option>PayPal</option>
            <option>Credit Card</option>
            <option>Bank Transfer</option>
          </select>
          <label className="flex items-center space-x-2">
            <input type="checkbox" className="w-4 h-4" />
            <span>Subscribe to our newsletter</span>
          </label>
          <Button>Donate</Button>
        </form>
      </section>
      <section id="contact" className="py-12 px-4 bg-blue-50">
        <h3 className="text-2xl font-bold mb-4">Get in Touch</h3>
        <form className="space-y-4 max-w-xl mx-auto">
          <Input placeholder="Name" />
          <Input placeholder="Email" />
          <Input placeholder="Subject" />
          <Textarea placeholder="Message" />
          <Button>Send Message</Button>
        </form>
      </section>
      <footer className="bg-blue-600 text-white p-6 mt-12">
        <div className="container mx-auto flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <p>© {new Date().getFullYear()} Emperors Meal. All rights reserved.</p>
          <div className="flex space-x-4">
            <a href="#"><Facebook /></a>
            <a href="#"><Twitter /></a>
            <a href="#"><Instagram /></a>
          </div>
        </div>
      </footer>
    </div>
  );
}
