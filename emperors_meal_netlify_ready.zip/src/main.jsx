import React from "react";
import ReactDOM from "react-dom/client";
import EmperorsMeal from "./App";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <EmperorsMeal />
  </React.StrictMode>
);
